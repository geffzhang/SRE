#!/usr/bin/env bash

systemctl daemon-reload 2> /dev/null
exit 0
