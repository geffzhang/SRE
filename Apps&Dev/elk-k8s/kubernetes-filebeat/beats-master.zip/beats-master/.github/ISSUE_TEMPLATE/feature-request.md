---
name: Enhancement request
about: Beats can't do all the things, but maybe it can do your things.

---

**Describe the enhancement:**

**Describe a specific use case for the enhancement or feature:**

